const stopwatch = document.getElementById('stopwatch')
stopwatch.addEventListener('click', (e) => {
    stopwatch.classList.toggle('running')
})